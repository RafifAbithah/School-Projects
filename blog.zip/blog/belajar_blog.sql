-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 04, 2020 at 09:38 AM
-- Server version: 10.1.30-MariaDB
-- PHP Version: 7.2.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `belajar_blog`
--

-- --------------------------------------------------------

--
-- Table structure for table `blog`
--

CREATE TABLE `blog` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `category` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `blog`
--

INSERT INTO `blog` (`id`, `title`, `content`, `created_at`, `updated_at`, `deleted_at`, `category`) VALUES
(1, 'makanan halal', 'banyak makanan halal', NULL, NULL, NULL, 'HUT RI ke - 75'),
(2, 'Ms.', 'Dolor dolores placeat eos accusantium. Cumque animi aut reiciendis voluptas dignissimos voluptatem enim error. Soluta saepe aperiam et vel aut fugit soluta.', '2020-10-24 23:13:04', '2020-10-24 23:13:04', NULL, 'Sheriff'),
(3, 'Ms.', 'Dolore ipsam quaerat illo. Nihil sed aliquam magni repellendus voluptas nam in. Aut quo qui corporis sapiente vitae.', '2020-10-24 23:13:04', '2020-10-24 23:13:04', NULL, 'Postal Service Clerk'),
(4, 'Prof.', 'Commodi aperiam nemo iure ut corporis. Non sit sunt animi suscipit non. Dolorem sunt ipsum blanditiis voluptatum inventore amet.', '2020-10-24 23:13:04', '2020-10-24 23:13:04', NULL, 'Underground Mining'),
(5, 'Ms.', 'Nemo esse dolore in. Praesentium laudantium aperiam laboriosam et aspernatur animi. Quidem vitae distinctio velit laborum natus laborum.', '2020-10-24 23:13:04', '2020-10-24 23:13:04', NULL, 'Fabric Pressers'),
(6, 'Dr.', 'Rerum blanditiis neque doloribus sit dolores reprehenderit laborum. Ut occaecati ut voluptatibus dolore. Doloribus temporibus earum similique corporis iure ex est voluptatibus.', '2020-10-24 23:13:04', '2020-10-24 23:13:04', NULL, 'Manager of Air Crew'),
(7, 'Prof.', 'Ipsa officia quo sunt vel adipisci a id voluptates. Quibusdam quia fugiat dolores ut. Autem maxime aperiam omnis sed blanditiis ipsa.', '2020-10-24 23:13:04', '2020-10-24 23:13:04', NULL, 'Medical Secretary'),
(8, 'Mr.', 'Est neque exercitationem voluptatem minus. Deserunt eius et vel doloremque incidunt consequatur id. Ut omnis et quia vitae ut minus qui fugiat. Occaecati inventore dolore numquam incidunt dicta nihil.', '2020-10-24 23:13:05', '2020-10-24 23:13:05', NULL, 'Animal Breeder'),
(9, 'Prof.', 'Dolores dolorem ut velit neque alias rerum tempore quia. Dolorem officiis sequi blanditiis placeat qui ut ut. Et officiis earum vero aut. Sit et eum voluptas quis vero et.', '2020-10-24 23:13:05', '2020-10-24 23:13:05', NULL, 'Assessor'),
(10, 'Mrs.', 'Recusandae voluptatum et occaecati tempora. Eaque distinctio et minus odio delectus. Veniam non sit cumque soluta sed autem dolorum. Quibusdam repudiandae esse vel sint cumque explicabo. Perferendis distinctio corrupti dolore reiciendis aspernatur qui.', '2020-10-24 23:13:05', '2020-10-24 23:13:05', NULL, 'Rolling Machine Setter'),
(11, 'Dr.', 'Accusamus sunt excepturi accusantium et. Itaque qui atque laboriosam. Eveniet necessitatibus dolorem sapiente.', '2020-10-24 23:13:05', '2020-10-24 23:13:05', NULL, 'Security Systems Installer OR Fire Alarm Systems Installer'),
(12, 'Dr.', 'Est ipsa facere et sed sequi maxime nihil. Aut eum consequatur voluptas quia eos consequuntur. Veritatis ut ipsum dolorem optio.', '2020-10-24 23:13:05', '2020-10-24 23:13:05', NULL, 'Order Filler'),
(13, 'Dr.', 'Nihil rem repudiandae asperiores. Quo vel nemo ut quasi impedit sit. Exercitationem nihil beatae recusandae consequatur rerum vel occaecati distinctio.', '2020-10-24 23:13:05', '2020-10-24 23:13:05', NULL, 'User Experience Manager'),
(14, 'Prof.', 'Quo optio dolores voluptates et. Quis accusantium eligendi quia suscipit eum aspernatur. Consequatur enim in dolores facilis aut dolorum officia. Sequi aut ut omnis occaecati a et aut.', '2020-10-24 23:13:05', '2020-10-24 23:13:05', NULL, 'Commercial Pilot'),
(15, 'Mr.', 'Non ea eligendi velit corrupti deleniti omnis. Officia dolore qui saepe beatae. Error eos quia voluptatem consectetur vitae deserunt. Qui consequatur quod necessitatibus dolor rerum aliquam. Dolorem fuga incidunt voluptatem veniam a non aut est.', '2020-10-24 23:13:05', '2020-10-24 23:13:05', NULL, 'Dental Hygienist'),
(16, 'Prof.', 'Id sapiente corrupti et alias similique quo optio. Qui nihil dolorem pariatur et eum molestiae occaecati. Pariatur omnis provident ut recusandae harum.', '2020-10-24 23:13:05', '2020-10-24 23:13:05', NULL, 'Dot Etcher'),
(17, 'Prof.', 'Assumenda eos qui libero magnam quae esse. Corrupti quo id in eaque. Dolore illum voluptas cumque delectus.', '2020-10-24 23:13:05', '2020-10-24 23:13:05', NULL, 'Product Safety Engineer'),
(18, 'Dr.', 'Doloribus aut ut quaerat. Aut repudiandae nobis et explicabo temporibus voluptas. Excepturi voluptatem eius quia iusto. Incidunt similique nobis sapiente illo ipsa. Ut deserunt ea explicabo doloremque sed nihil tempora.', '2020-10-24 23:13:05', '2020-10-24 23:13:05', NULL, 'Painter and Illustrator'),
(19, 'Dr.', 'Natus magnam totam delectus ut non reprehenderit qui voluptas. Voluptatem nemo aut voluptatem cumque dignissimos nemo. Voluptatibus et libero et hic et cumque dolores. Voluptatem ipsum quas assumenda animi.', '2020-10-24 23:13:05', '2020-10-24 23:13:05', NULL, 'Bench Jeweler'),
(20, 'Ms.', 'Consequatur debitis consequatur vero quam. Consequatur nesciunt molestias rerum debitis consequatur aut. Id quas nostrum est nesciunt sapiente laborum tempora illum.', '2020-10-24 23:13:05', '2020-10-24 23:13:05', NULL, 'Gaming Supervisor'),
(21, 'Mrs.', 'Qui aut possimus nesciunt at quasi nihil. Architecto quia ducimus quas natus sed in architecto beatae. Doloribus esse id labore repudiandae officia.', '2020-10-24 23:13:05', '2020-10-24 23:13:05', NULL, 'Production Planner'),
(22, 'Dr.', 'Quas enim at deserunt voluptas. Unde laudantium sed est eos. Quae minus dolores molestiae ut. Dolorum aut ipsum velit voluptatem aut fugit. Doloremque aspernatur sit libero est nam quo vel.', '2020-10-24 23:13:05', '2020-10-24 23:13:05', NULL, 'Weapons Specialists'),
(23, 'Mr.', 'Ut ex aspernatur eos magni quod facilis. Aut est ut sint nisi libero ut qui recusandae. Dolor ducimus ipsa tempora quis eum voluptatem. Sed soluta vel fugiat perspiciatis. Sed ut sed eaque natus et.', '2020-10-24 23:13:05', '2020-10-24 23:13:05', NULL, 'Radio and Television Announcer'),
(24, 'Dr.', 'Ipsa voluptatem consequuntur et consectetur et sit est. Expedita consequatur dolorem aspernatur. Blanditiis quia atque dolorum sed. Fugiat explicabo architecto possimus in perspiciatis aut nihil. Praesentium necessitatibus praesentium praesentium.', '2020-10-24 23:13:05', '2020-10-24 23:13:05', NULL, 'Sawing Machine Setter'),
(25, 'Dr.', 'Aut animi recusandae voluptatem impedit. Omnis consequatur aut id dolor. Deleniti ut et dolore et commodi eveniet.', '2020-10-24 23:13:05', '2020-10-24 23:13:05', NULL, 'Communication Equipment Worker'),
(26, 'Prof.', 'Explicabo illo aut sint doloribus. Facilis assumenda reprehenderit vel velit. Excepturi quia quis harum ut.', '2020-10-24 23:13:05', '2020-10-24 23:13:05', NULL, 'Choreographer'),
(27, 'Mrs.', 'Delectus sit placeat sed non aut autem voluptate fugit. Eaque sequi nam atque odit ut ratione. Explicabo doloribus vel reiciendis ipsa cum nisi tenetur.', '2020-10-24 23:13:06', '2020-10-24 23:13:06', NULL, 'Library Science Teacher'),
(28, 'Mrs.', 'Tempore in accusamus et nam dolores sit ipsam. Cupiditate ipsum quas id consectetur. Aut sint nihil atque et doloribus fugiat possimus. Ratione error quod quibusdam nostrum aut suscipit.', '2020-10-24 23:13:06', '2020-10-24 23:13:06', NULL, 'Biochemist'),
(29, 'Mrs.', 'Id nesciunt dolorum ad. Corporis sunt id mollitia dolorum dolorum. Totam consequatur debitis ut vitae dolorum veniam.', '2020-10-24 23:13:06', '2020-10-24 23:13:06', NULL, 'Annealing Machine Operator'),
(30, 'Dr.', 'Fuga excepturi ut enim modi molestiae nihil veritatis. Corporis qui vel excepturi. Rem dolorem nostrum voluptatibus recusandae ut. Officia ea dolorem et.', '2020-10-24 23:13:06', '2020-10-24 23:13:06', NULL, 'Automotive Mechanic'),
(31, 'Ms.', 'Reiciendis ab omnis necessitatibus eum similique dolorum. Dolorem unde fugit quaerat. Magni sunt earum natus maxime suscipit impedit incidunt.', '2020-10-24 23:13:06', '2020-10-24 23:13:06', NULL, 'Advertising Manager OR Promotions Manager'),
(32, 'Ms.', 'Hic molestias doloribus non beatae. Praesentium doloribus et et sed est eaque. Hic et suscipit quis eos et.', '2020-10-24 23:13:06', '2020-10-24 23:13:06', NULL, 'Talent Acquisition Manager'),
(33, 'Prof.', 'Tempora et quia ut. Voluptatem ex totam explicabo natus quod. Expedita est quasi fugit qui tenetur autem inventore. Totam voluptatum molestias architecto qui. Ipsa odio rerum maiores aperiam et ut expedita.', '2020-10-24 23:13:06', '2020-10-24 23:13:06', NULL, 'Computer Operator'),
(34, 'Mr.', 'Impedit aut et pariatur animi impedit. Fugit placeat inventore reiciendis eius laudantium labore minima ullam. Quaerat dolor voluptas mollitia autem non qui neque nemo.', '2020-10-24 23:13:06', '2020-10-24 23:13:06', NULL, 'Healthcare Practitioner'),
(35, 'Prof.', 'Labore dolorum inventore fugiat et doloribus doloremque itaque. In illum debitis velit amet voluptates. Ut officiis aut ipsam voluptate repellat.', '2020-10-24 23:13:06', '2020-10-24 23:13:06', NULL, 'Mechanical Inspector'),
(36, 'Dr.', 'Voluptatem nesciunt assumenda consequatur et. Recusandae sit ullam hic consectetur ipsam ea. Consequatur qui quia harum sit.', '2020-10-24 23:13:06', '2020-10-24 23:13:06', NULL, 'Education Administrator'),
(37, 'Prof.', 'Et ut velit ullam repudiandae reprehenderit. Earum eos et placeat consequatur provident voluptatum. Et dicta sint voluptatem quam.', '2020-10-24 23:13:06', '2020-10-24 23:13:06', NULL, 'Caption Writer'),
(38, 'Dr.', 'Enim ad architecto nihil et fuga facere soluta. Est ex quo quis qui. Atque velit enim et commodi.', '2020-10-24 23:13:06', '2020-10-24 23:13:06', NULL, 'Animal Care Workers'),
(39, 'Miss', 'Odit qui corrupti iure eos eos. Harum voluptas repudiandae deleniti voluptas molestias officiis rerum. Ea perspiciatis officia natus voluptatem quis et sed. Earum facilis quam ex voluptatum deserunt quaerat error.', '2020-10-24 23:13:06', '2020-10-24 23:13:06', NULL, 'Interviewer'),
(40, 'Mr.', 'Repudiandae sapiente saepe eos qui. Perferendis quam sint id at.', '2020-10-24 23:13:06', '2020-10-24 23:13:06', NULL, 'Sheet Metal Worker'),
(41, 'Prof.', 'Nam nulla omnis sed vitae suscipit. Non autem iure et adipisci veritatis odio. Eum distinctio voluptas reiciendis aut adipisci et rem.', '2020-10-24 23:13:06', '2020-10-24 23:13:06', NULL, 'Computer Software Engineer'),
(42, 'Ms.', 'Error assumenda unde error distinctio. Mollitia amet vitae iusto reprehenderit doloremque accusamus magni. Nobis assumenda odio voluptas qui. Quia voluptates ducimus ea dignissimos cupiditate commodi saepe.', '2020-10-24 23:13:06', '2020-10-24 23:13:06', NULL, 'Historian'),
(43, 'Miss', 'Similique ut soluta ut commodi. Porro est quae inventore et perferendis et. Laudantium non occaecati maiores qui.', '2020-10-24 23:13:06', '2020-10-24 23:13:06', NULL, 'Nuclear Medicine Technologist'),
(44, 'Mr.', 'Modi sunt aliquid optio molestias aliquid eveniet tempore iusto. Autem praesentium velit qui dolorem. Omnis deleniti exercitationem ut qui sequi.', '2020-10-24 23:13:06', '2020-10-24 23:13:06', NULL, 'Stock Broker'),
(45, 'Mr.', 'Explicabo quisquam nobis sit possimus. Aut repellendus officiis et ut.', '2020-10-24 23:13:06', '2020-10-24 23:13:06', NULL, 'Fast Food Cook'),
(46, 'Dr.', 'Animi ducimus quia alias consequatur temporibus. Rerum est aut non voluptatum et ea ipsam.', '2020-10-24 23:13:06', '2020-10-24 23:13:06', NULL, 'Radiologic Technologist'),
(47, 'Dr.', 'Quia quas quis animi aliquam id magnam autem. Nulla quis fugit distinctio id id qui. Minima qui omnis repellat ad voluptatem natus cumque vel.', '2020-10-24 23:13:06', '2020-10-24 23:13:06', NULL, 'Keyboard Instrument Repairer and Tuner'),
(48, 'Miss', 'Et fugiat vel occaecati omnis. Dolore ut aut et libero. Adipisci iusto quasi veritatis laboriosam. Doloribus ab aut facere voluptatem eum maxime.', '2020-10-24 23:13:06', '2020-10-24 23:13:06', NULL, 'Ship Carpenter and Joiner'),
(49, 'Dr.', 'Reprehenderit commodi at aut facilis consequatur. Quia aut totam porro quia. Repellat tenetur accusantium consectetur quisquam tempore sed. Magnam quod modi rerum est voluptatem.', '2020-10-24 23:13:06', '2020-10-24 23:13:06', NULL, 'Recreation Worker'),
(50, 'Ms.', 'Beatae aut nihil qui non doloremque doloremque. Iure alias delectus ad qui et. Error aut placeat voluptas nostrum voluptatem. Qui reprehenderit et praesentium et.', '2020-10-24 23:13:06', '2020-10-24 23:13:06', NULL, 'Textile Machine Operator'),
(51, 'Mr.', 'Consequatur ea quam debitis laborum. Impedit dolorem veniam dolorum voluptatem aut quis est. Velit error veritatis fugiat aut beatae qui.', '2020-10-24 23:13:06', '2020-10-24 23:13:06', NULL, 'Financial Services Sales Agent'),
(52, 'Dr.', 'Distinctio autem odit qui dolorem vitae aut. Voluptatibus aut consequatur eveniet hic est praesentium et laudantium. Accusamus quo nobis mollitia. Beatae deserunt nihil omnis molestiae.', '2020-10-24 23:13:06', '2020-10-24 23:13:06', NULL, 'Industrial Equipment Maintenance'),
(53, 'Prof.', 'Reprehenderit eum voluptatem incidunt. Et magni cum fugiat exercitationem ad sit.', '2020-10-24 23:13:07', '2020-10-24 23:13:07', NULL, 'Advertising Manager OR Promotions Manager'),
(54, 'Ms.', 'Vero quod voluptatem voluptas maiores veritatis dolorum. Sed dolor qui blanditiis impedit. Ut perferendis quo neque impedit adipisci enim.', '2020-10-24 23:13:07', '2020-10-24 23:13:07', NULL, 'Administrative Support Supervisors'),
(55, 'Mrs.', 'Deleniti perferendis dolorum est esse consequatur ipsam eligendi. Veniam in quis iste. Est voluptas fugit rerum earum sed.', '2020-10-24 23:13:07', '2020-10-24 23:13:07', NULL, 'Social Service Specialists'),
(56, 'Mr.', 'Et dolore minus nemo. Nobis ipsam possimus aut deleniti.', '2020-10-24 23:13:07', '2020-10-24 23:13:07', NULL, 'Protective Service Worker'),
(57, 'Miss', 'Autem odio sed tempore iste quam nam. Officiis dolor non sed odit. Maiores incidunt occaecati perspiciatis incidunt esse quaerat consequatur.', '2020-10-24 23:13:07', '2020-10-24 23:13:07', NULL, 'Casting Machine Set-Up Operator'),
(58, 'Prof.', 'Animi enim necessitatibus praesentium ducimus hic. Est a consectetur qui. Cupiditate consectetur cum rem rerum.', '2020-10-24 23:13:07', '2020-10-24 23:13:07', NULL, 'Police and Sheriffs Patrol Officer'),
(59, 'Dr.', 'Aut in dolor nisi in qui tempore deserunt. In laudantium autem eligendi sunt blanditiis sed maiores. In a sed laudantium minus soluta.', '2020-10-24 23:13:07', '2020-10-24 23:13:07', NULL, 'Portable Power Tool Repairer'),
(60, 'Dr.', 'Ut necessitatibus eos id quia consequatur sapiente voluptatem. Provident veniam qui consequatur odit non. Velit enim et autem non. Quia a quibusdam id quia sunt expedita.', '2020-10-24 23:13:07', '2020-10-24 23:13:07', NULL, 'Automotive Technician'),
(61, 'Ms.', 'Similique et ullam ut aspernatur illo sapiente. Id est in ipsum assumenda ut sint repellat. Ipsa asperiores quia quod animi. Enim necessitatibus molestiae corrupti.', '2020-10-24 23:13:07', '2020-10-24 23:13:07', NULL, 'Psychiatric Technician'),
(62, 'Dr.', 'Impedit optio fugit magni dolor veniam harum. Nobis dolores alias laudantium architecto cum. Illo nostrum ipsam ab voluptatem ut temporibus.', '2020-10-24 23:13:07', '2020-10-24 23:13:07', NULL, 'Art Director'),
(63, 'Miss', 'Vitae similique doloremque est maxime blanditiis optio. Quis nisi qui fuga. Commodi reiciendis accusamus nam saepe sint modi.', '2020-10-24 23:13:07', '2020-10-24 23:13:07', NULL, 'Postal Service Clerk'),
(64, 'Dr.', 'Perspiciatis quas pariatur magnam nesciunt. Vel commodi fuga ut. Exercitationem eligendi quo est sit.', '2020-10-24 23:13:07', '2020-10-24 23:13:07', NULL, 'Recyclable Material Collector'),
(65, 'Mr.', 'Quo consequuntur enim rerum sit et. Non non deleniti eos tempora. Tempore aut repellat incidunt autem non aliquam. Blanditiis iure sed sint ratione asperiores.', '2020-10-24 23:13:07', '2020-10-24 23:13:07', NULL, 'Conveyor Operator'),
(66, 'Dr.', 'Accusamus et dicta sint velit ut repellendus debitis molestiae. Nihil omnis dolor molestias est quam ea. Qui pariatur labore recusandae qui beatae.', '2020-10-24 23:13:07', '2020-10-24 23:13:07', NULL, 'Maintenance Worker'),
(67, 'Mrs.', 'Rerum sequi at magnam. Laboriosam omnis odit ea qui eos aut. Totam nesciunt earum vel.', '2020-10-24 23:13:07', '2020-10-24 23:13:07', NULL, 'Farm Equipment Mechanic'),
(68, 'Ms.', 'Omnis aliquam recusandae ea cumque magni eos vero rerum. Numquam doloremque rem est nostrum quibusdam laboriosam quia. Qui distinctio consectetur qui rem.', '2020-10-24 23:13:07', '2020-10-24 23:13:07', NULL, 'Loading Machine Operator'),
(69, 'Mr.', 'Quo necessitatibus omnis et autem vitae. Minus reiciendis perspiciatis quia qui ut id rerum. Asperiores sed qui quo animi ut voluptatem provident illo. Sed et quis et quia. Nulla molestiae vero voluptas corporis.', '2020-10-24 23:13:07', '2020-10-24 23:13:07', NULL, 'License Clerk'),
(70, 'Miss', 'Sunt illum voluptate quidem soluta laboriosam. Error doloremque reprehenderit eligendi rerum quos. Consequuntur et velit esse quisquam.', '2020-10-24 23:13:07', '2020-10-24 23:13:07', NULL, 'Diamond Worker'),
(71, 'Mr.', 'Dignissimos tempore fuga molestiae et enim eum. Quos pariatur in suscipit ipsam consequatur aut. Rerum sint veritatis architecto non sed culpa. Quas cumque aut reiciendis asperiores.', '2020-10-24 23:13:07', '2020-10-24 23:13:07', NULL, 'Precious Stone Worker'),
(72, 'Dr.', 'Laborum suscipit temporibus ut quos tenetur autem. Quod non fugit ad beatae blanditiis. Quae facilis tempora dignissimos voluptate et. Corporis nesciunt in et quo optio ut.', '2020-10-24 23:13:07', '2020-10-24 23:13:07', NULL, 'Engineering Teacher'),
(73, 'Dr.', 'Laudantium est veritatis commodi pariatur sunt dolorem aliquam. Porro aut quasi distinctio amet. Aut quas enim ab rerum quod nihil cum.', '2020-10-24 23:13:07', '2020-10-24 23:13:07', NULL, 'Travel Guide'),
(74, 'Mr.', 'Corporis iure possimus ad dolor dolores aliquid rerum. Voluptas minima architecto impedit iste voluptate sint sed quia.', '2020-10-24 23:13:07', '2020-10-24 23:13:07', NULL, 'Soil Scientist OR Plant Scientist'),
(75, 'Prof.', 'Recusandae et facere culpa numquam sed. Sunt aut veniam vel. Dolore mollitia qui quae vitae sapiente repudiandae.', '2020-10-24 23:13:07', '2020-10-24 23:13:07', NULL, 'Costume Attendant'),
(76, 'Prof.', 'Reiciendis nihil et laudantium vel culpa mollitia. Odio qui placeat totam dolor facere. Fugiat quis voluptatum qui veritatis. Alias voluptate laudantium laudantium qui accusamus quod.', '2020-10-24 23:13:07', '2020-10-24 23:13:07', NULL, 'Agricultural Crop Farm Manager'),
(77, 'Dr.', 'Placeat et mollitia repudiandae quas accusamus delectus nihil. Magni tenetur quia quas modi. Fuga laborum iusto sit eligendi. Qui cumque veritatis incidunt. Atque nobis sit inventore quod unde aut libero qui.', '2020-10-24 23:13:07', '2020-10-24 23:13:07', NULL, 'Chemist'),
(78, 'Prof.', 'Dolore voluptatem asperiores ex vero nemo perspiciatis. Architecto maxime voluptate dignissimos impedit ab molestiae. In sint quo nostrum ullam id nesciunt.', '2020-10-24 23:13:07', '2020-10-24 23:13:07', NULL, 'Skin Care Specialist'),
(79, 'Dr.', 'Tempora eaque possimus asperiores blanditiis molestiae explicabo. Labore assumenda fuga cupiditate qui repudiandae.', '2020-10-24 23:13:08', '2020-10-24 23:13:08', NULL, 'Housekeeper'),
(80, 'Prof.', 'Iste doloribus non vel et illum consequuntur tenetur. Ullam itaque enim illum sapiente consectetur. Eligendi qui fuga ab error.', '2020-10-24 23:13:08', '2020-10-24 23:13:08', NULL, 'Corporate Trainer'),
(81, 'Mrs.', 'Ullam numquam natus ipsa sed illum in. Qui sunt voluptatem enim omnis reiciendis. Cum consequatur architecto voluptatem animi animi.', '2020-10-24 23:13:08', '2020-10-24 23:13:08', NULL, 'Insurance Sales Agent'),
(82, 'Prof.', 'Facilis labore et ut voluptates est quis voluptate. Ut cupiditate id et reprehenderit voluptas qui earum. Quasi dolore vero eius aut. Minus ut rerum qui voluptate minima et.', '2020-10-24 23:13:08', '2020-10-24 23:13:08', NULL, 'Industrial Equipment Maintenance'),
(83, 'Prof.', 'Non sed consequuntur ipsum delectus exercitationem. Qui dolor inventore velit et. Nesciunt et quia nam itaque doloremque asperiores.', '2020-10-24 23:13:08', '2020-10-24 23:13:08', NULL, 'Model Maker'),
(84, 'Dr.', 'Eveniet sed voluptatem vel perspiciatis nobis ipsum sed occaecati. Et nihil temporibus non in.', '2020-10-24 23:13:08', '2020-10-24 23:13:08', NULL, 'Pharmacist'),
(85, 'Ms.', 'Non excepturi dolorem officia qui consectetur. Harum quam et autem iure repellendus. Amet sint nesciunt repudiandae eius accusantium nihil at.', '2020-10-24 23:13:08', '2020-10-24 23:13:08', NULL, 'Sociologist'),
(86, 'Dr.', 'Praesentium molestiae facere expedita labore laudantium. Repellat est adipisci occaecati fugit doloremque. Pariatur quo tempore officiis expedita odit ducimus est.', '2020-10-24 23:13:08', '2020-10-24 23:13:08', NULL, 'Medical Scientists'),
(87, 'Mr.', 'Consectetur at molestias dolores aut vitae non non vel. Illo placeat animi voluptatem porro voluptas exercitationem unde. Delectus dolorum eius est ipsa et.', '2020-10-24 23:13:08', '2020-10-24 23:13:08', NULL, 'Sawing Machine Tool Setter'),
(88, 'Mr.', 'Similique fugit sapiente autem quo. Vel quibusdam quidem accusamus quos.', '2020-10-24 23:13:08', '2020-10-24 23:13:08', NULL, 'Air Crew Officer'),
(89, 'Prof.', 'Sunt eos dolores suscipit voluptas qui. Voluptatum consequatur eius tempore quisquam. Est exercitationem officiis voluptatem quaerat velit. Eum corrupti dolorem veniam et quia veniam. Aut est dolor qui sint consectetur.', '2020-10-24 23:13:08', '2020-10-24 23:13:08', NULL, 'Marking Machine Operator'),
(90, 'Miss', 'Quis est quos sed perspiciatis ut doloremque debitis. Nihil sint doloribus dignissimos aliquam modi natus id. Ducimus quam sunt velit tenetur.', '2020-10-24 23:13:08', '2020-10-24 23:13:08', NULL, 'Bench Jeweler'),
(91, 'Prof.', 'Maiores error explicabo eius aliquid. Deserunt quis dolorem maiores dolores.', '2020-10-24 23:13:08', '2020-10-24 23:13:08', NULL, 'Jeweler'),
(92, 'Mr.', 'Quibusdam blanditiis velit veritatis voluptas expedita. Numquam eveniet saepe at labore. Magnam modi nihil dolores aut. At nemo occaecati rerum temporibus voluptas. Quisquam quia ut est facilis vero.', '2020-10-24 23:13:08', '2020-10-24 23:13:08', NULL, 'Agricultural Engineer'),
(93, 'Mrs.', 'Praesentium deserunt occaecati aut aut et voluptatem neque asperiores. Voluptas aut laborum temporibus aliquid veritatis ea est. Rerum qui non modi eligendi ut.', '2020-10-24 23:13:08', '2020-10-24 23:13:08', NULL, 'Soldering Machine Setter'),
(94, 'Dr.', 'Distinctio magnam aut nam dolor. Sed illo modi soluta porro. Suscipit reprehenderit fugit et ipsa aut. Reiciendis voluptatum laboriosam omnis explicabo sunt.', '2020-10-24 23:13:08', '2020-10-24 23:13:08', NULL, 'Talent Director'),
(95, 'Prof.', 'Voluptas repellat eligendi sed error voluptatem et accusamus. Odio laborum deleniti voluptatem harum praesentium ad doloribus. Error molestiae omnis dolores sint rerum ab amet.', '2020-10-24 23:13:08', '2020-10-24 23:13:08', NULL, 'Algorithm Developer'),
(96, 'Prof.', 'Libero quasi repudiandae deleniti sit ut velit dolor. Fuga error fuga dignissimos labore perspiciatis eligendi praesentium. Dolor numquam deleniti quisquam est incidunt minima aliquid.', '2020-10-24 23:13:08', '2020-10-24 23:13:08', NULL, 'Visual Designer'),
(97, 'Prof.', 'Occaecati consequatur deleniti quia in. Omnis sint nulla id corrupti id ut animi. Quibusdam alias eligendi accusamus assumenda.', '2020-10-24 23:13:08', '2020-10-24 23:13:08', NULL, 'Naval Architects'),
(98, 'Prof.', 'Eum doloremque aut quos perspiciatis velit aut. Eum est illo repellendus praesentium nemo. Quo nemo id sed dolorem natus et. Omnis beatae eius alias et rerum quidem iste.', '2020-10-24 23:13:08', '2020-10-24 23:13:08', NULL, 'Cutting Machine Operator'),
(99, 'Prof.', 'Repellendus et sapiente aut exercitationem. Quisquam et quis optio delectus voluptatem necessitatibus quo. Voluptas voluptatum exercitationem rem odio aut omnis a ratione. Magnam assumenda quae et nemo.', '2020-10-24 23:13:08', '2020-10-24 23:13:08', NULL, 'Cooling and Freezing Equipment Operator'),
(100, 'Prof.', 'Esse recusandae totam perspiciatis rerum voluptas et vel. Et saepe nostrum voluptatem mollitia ut error. Iusto architecto voluptas laudantium deleniti fuga. Ducimus cumque nemo odit dolorem qui.', '2020-10-24 23:13:08', '2020-10-24 23:13:08', NULL, 'Electrolytic Plating Machine Operator'),
(101, 'Dr.', 'Sapiente et molestiae voluptate quas nemo ullam aut itaque. Iste fugiat fugit iste soluta unde natus. Sint omnis et officia illo accusamus et ipsam.', '2020-10-24 23:13:08', '2020-10-24 23:13:08', NULL, 'Service Station Attendant');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(5, '2020_10_22_012024_create_blog_table', 1),
(6, '2020_10_22_015353_add_category_in_blog_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `blog`
--
ALTER TABLE `blog`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `blog`
--
ALTER TABLE `blog`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=102;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
